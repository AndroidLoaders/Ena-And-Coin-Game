package com.example.peacock.newcoingame;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.peacock.newcoingame.Flip_3d_Animation.Flip3dAnimation;
import com.example.peacock.newcoingame.Rainfall_Effect.RainFallView;

public class Game_Activity extends AppCompatActivity implements View.OnTouchListener,
        Animation.AnimationListener, View.OnClickListener {

    private int screen_width, screen_height, width_of_single_tv, height_of_single_tv,
            height_of_matrix_layout,
            height_of_score_layout;

    private int players_points_counter, player_1_points, player_2_points;

    private int counter = 0, temp_row = 0, touched_column = 0, empty_positiosns = 0, centerX = 0,
            centerY = 0, fromAngle = 0, toAngle = 180;

    private boolean dontTouch = false, flag_for_player_one_turn = true, is_game_tied = false,
            is_playing_first_time = true;

    //=========================================================

    private SharedPreferences sp_best_score;

    //=========================================================

    private int[][] values = {{0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0}};

    private int[] location = new int[2];

    private int[] location_of_slider, temp_location;

    private int[][] win_position_array;

    //=========================================================

    private Animation slide_topDown, slide_left_right, check_animation;

    private Flip3dAnimation flip_3d;

    //=========================================================

    private TextView[][] tv_array = new TextView[6][6];

    private TextView tv_generated_view, tv_slider, tv_playerTurn;

    private TextView tv_pl1_best_score, tv_pl2_best_score, tv_pl1_coins, tv_pl2_coins, tv_pl1_score,
            tv_pl2_score;

    private RelativeLayout rl_game_layout, rl_matrix_layout;

    private FrameLayout fl_slider;

    private RainFallView rfv_rainfall_pink, rfv_rainfall_white;

    private Dialog win_dialog;

    //=========================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        screen_width = getResources().getDisplayMetrics().widthPixels;

        screen_height = getResources().getDisplayMetrics().heightPixels;

        setContentView(R.layout.game_activity);

        sp_best_score = getSharedPreferences("best_score", Context.MODE_PRIVATE);

        rl_game_layout = (RelativeLayout) findViewById(R.id.rl_game_layout);

        tv_playerTurn = (TextView) findViewById(R.id.tv_playerTurn);

        tv_slider = (TextView) findViewById(R.id.tv_slider);

        rl_matrix_layout = (RelativeLayout) findViewById(R.id.rl_matrix_layout);
        rl_matrix_layout.setOnTouchListener(this);

        tv_array[0][0] = (TextView) findViewById(R.id.tv_00);
        tv_array[0][1] = (TextView) findViewById(R.id.tv_01);
        tv_array[0][2] = (TextView) findViewById(R.id.tv_02);
        tv_array[0][3] = (TextView) findViewById(R.id.tv_03);
        tv_array[0][4] = (TextView) findViewById(R.id.tv_04);
        tv_array[0][5] = (TextView) findViewById(R.id.tv_05);

        tv_array[1][0] = (TextView) findViewById(R.id.tv_10);
        tv_array[1][1] = (TextView) findViewById(R.id.tv_11);
        tv_array[1][2] = (TextView) findViewById(R.id.tv_12);
        tv_array[1][3] = (TextView) findViewById(R.id.tv_13);
        tv_array[1][4] = (TextView) findViewById(R.id.tv_14);
        tv_array[1][5] = (TextView) findViewById(R.id.tv_15);

        tv_array[2][0] = (TextView) findViewById(R.id.tv_20);
        tv_array[2][1] = (TextView) findViewById(R.id.tv_21);
        tv_array[2][2] = (TextView) findViewById(R.id.tv_22);
        tv_array[2][3] = (TextView) findViewById(R.id.tv_23);
        tv_array[2][4] = (TextView) findViewById(R.id.tv_24);
        tv_array[2][5] = (TextView) findViewById(R.id.tv_25);

        tv_array[3][0] = (TextView) findViewById(R.id.tv_30);
        tv_array[3][1] = (TextView) findViewById(R.id.tv_31);
        tv_array[3][2] = (TextView) findViewById(R.id.tv_32);
        tv_array[3][3] = (TextView) findViewById(R.id.tv_33);
        tv_array[3][4] = (TextView) findViewById(R.id.tv_34);
        tv_array[3][5] = (TextView) findViewById(R.id.tv_35);

        tv_array[4][0] = (TextView) findViewById(R.id.tv_40);
        tv_array[4][1] = (TextView) findViewById(R.id.tv_41);
        tv_array[4][2] = (TextView) findViewById(R.id.tv_42);
        tv_array[4][3] = (TextView) findViewById(R.id.tv_43);
        tv_array[4][4] = (TextView) findViewById(R.id.tv_44);
        tv_array[4][5] = (TextView) findViewById(R.id.tv_45);

        tv_array[5][0] = (TextView) findViewById(R.id.tv_50);
        tv_array[5][1] = (TextView) findViewById(R.id.tv_51);
        tv_array[5][2] = (TextView) findViewById(R.id.tv_52);
        tv_array[5][3] = (TextView) findViewById(R.id.tv_53);
        tv_array[5][4] = (TextView) findViewById(R.id.tv_54);
        tv_array[5][5] = (TextView) findViewById(R.id.tv_55);

        tv_pl1_best_score = (TextView) findViewById(R.id.tv_pl1_best_score);

        tv_pl2_best_score = (TextView) findViewById(R.id.tv_pl2_best_score);

        tv_pl1_coins = (TextView) findViewById(R.id.tv_pl1_coins);

        tv_pl2_coins = (TextView) findViewById(R.id.tv_pl2_coins);

        tv_pl1_score = (TextView) findViewById(R.id.tv_pl1_score);

        tv_pl2_score = (TextView) findViewById(R.id.tv_pl2_score);

        /*animate_slider = ObjectAnimator.ofFloat(tv_slider, "rotationY", 0.0f, 360.0f);
        animate_slider.setDuration(800);
        animate_slider.setRepeatCount(ObjectAnimator.INFINITE);
        animate_slider.setInterpolator(new AccelerateDecelerateInterpolator());*/

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        if (dontTouch) {

            return true;

        } else {

            for (touched_column = 0; touched_column < values.length; touched_column++) {

                tv_array[0][touched_column].getLocationOnScreen(location);

                int temp = location[0] + tv_array[0][0].getWidth();

                if ((int) event.getRawX() <= temp && (int) event.getRawX() >= location[0]) {

                    break;

                }
            }

            switch (event.getAction()) {

                case MotionEvent.ACTION_UP:

                    if (touched_column >= 0 && touched_column < values.length) {

                        if (values[0][touched_column] > 0) {

                        /* this will check if first(top) position in perticular column is already
                         filled then coin should not drop*/

                            return true;

                        }

                        RelativeLayout.LayoutParams Params1 = new RelativeLayout.LayoutParams(tv_array[0][0].getWidth(),
                                tv_array[0][0].getHeight());

                        Params1.setMargins(tv_array[0][touched_column].getLeft(), tv_array[0][touched_column].getTop(),
                                tv_array[0][touched_column].getRight(), tv_array[0][touched_column].getBottom());

                        tv_generated_view = new TextView(Game_Activity.this);
                        tv_generated_view.setBackgroundResource(R.drawable.circle);
                        tv_generated_view.setGravity(Gravity.CENTER);
                        tv_generated_view.setText("");
                        tv_generated_view.setLayoutParams(Params1);
                        if (flag_for_player_one_turn) {

                            tv_generated_view.setBackgroundResource(R.drawable.circle_red);

                        } else {

                            tv_generated_view.setBackgroundResource(R.drawable.circle_blue);

                        }

                        tv_generated_view.setVisibility(View.INVISIBLE);
                        rl_matrix_layout.addView(tv_generated_view);

                        temp_row = 0;

                        for (int row = (values.length - 1); row >= 0; row--) {

                            if (values[row][touched_column] == 0) {

                                temp_row = row;

                                break;

                            }
                        }

                        slideToDown();

                    }

                    break;

            }

            return true;

        }
    }

    @SuppressLint("NewApi")
    private void slideToDown() {

        temp_location = new int[2];

        tv_array[0][touched_column].getLocationOnScreen(temp_location);

        if (!dontTouch) {

            if (is_playing_first_time) {

                is_playing_first_time = false;

                width_of_single_tv = tv_array[0][0].getWidth();

                height_of_single_tv = tv_array[0][0].getHeight();

                height_of_score_layout = findViewById(R.id.ll_scorelayout).getMeasuredHeight();

                height_of_matrix_layout = rl_matrix_layout.getHeight();

                centerX = (int) (tv_slider.getWidth() / 2.0f);

                centerY = (int) (tv_slider.getHeight() / 2.0f);

                //int slide_to_position = temp_location[0] + width_of_single_tv;

                slide_left_right = new TranslateAnimation(0, temp_location[0], 0, 0);

                slide_topDown = new TranslateAnimation(0, 0, 0, (screen_height - (height_of_matrix_layout -
                        (height_of_single_tv * temp_row)) - height_of_score_layout));

            } else {

                slide_left_right = new TranslateAnimation(location_of_slider[0], temp_location[0], 0, 0);

                slide_topDown = new TranslateAnimation(0, 0, 0, (screen_height - (height_of_matrix_layout -
                        (height_of_single_tv * temp_row)) - 33 - height_of_score_layout));

                //flip_3d = new Flip3dAnimation(fromAngle, toAngle, centerX, centerY);

            }
        }

        slide_left_right.setDuration(800);
        slide_left_right.setFillEnabled(true);
        slide_left_right.setFillBefore(true);
        slide_left_right.setFillAfter(true);
        slide_left_right.setAnimationListener(this);

        dontTouch = true;

        tv_slider.startAnimation(slide_left_right);
        /*int height_of_score_layout = findViewById(R.id.ll_scorelayout).getMeasuredHeight();
        int height_of_matrix_layout = findViewById(R.id.rl_matrix_layout).getHeight();
        int height_of_tv = tv_array[temp_row][touched_column].getHeight();*/

        /*if (temp_row >= 0 && temp_row < 3) {

            slide_topDown = new TranslateAnimation(0, 0, 0, (screen_height - (height_of_matrix_layout -
                    (height_of_single_tv * temp_row)) - 33 - height_of_score_layout));

        } else {*/

        //}

        slide_topDown.setInterpolator(new BounceInterpolator());
        slide_topDown.setDuration(1000);
        slide_topDown.setFillEnabled(true);
        slide_topDown.setFillAfter(true);
        slide_topDown.setAnimationListener(this);

    }

    @Override
    public void onAnimationStart(Animation animation) {

        if (animation == slide_left_right) {

            dontTouch = true;

        }
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

        if (animation == slide_left_right) {

            tv_generated_view.startAnimation(slide_topDown);

            location_of_slider = new int[2];

            location_of_slider = temp_location;

        }

        if (animation == slide_topDown) {

            tv_generated_view.clearAnimation();

            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(width_of_single_tv, height_of_single_tv);
            lp.setMargins(0, tv_generated_view.getWidth(), 0, 0);
            lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            tv_generated_view.setLayoutParams(lp);

            tv_generated_view.setVisibility(View.GONE);

            if (flag_for_player_one_turn) {

                int player = 1;

                players_points_counter++;

                values[temp_row][touched_column] = 1;

                flag_for_player_one_turn = false;

                tv_array[temp_row][touched_column].setBackgroundResource(R.drawable.circle_red);

                tv_pl1_coins.setText(String.valueOf(players_points_counter));

                if (check_for_winner(temp_row, touched_column, player)) {

                    player_1_points = (players_points_counter * 100) + (empty_positiosns * 500);

                    tv_pl1_score.setText("" + player_1_points);

                    updateScoreInSharedPreference("player_1_best_score", String.valueOf(player_1_points),
                            player_1_points);

                    //create dialog for winner

                    // dontTouch = true;

                    return;

                } else {

                    if (!is_game_tied) {

                        tv_pl1_score.setText("" + (players_points_counter * 100));

                        /*tv_pl2_img.setBackgroundResource(R.drawable.player_2_enable);

                        tv_pl1_img.setBackgroundResource(R.drawable.player_1_disable);*/

                        tv_playerTurn.setText(R.string.player_2);

                        tv_playerTurn.setBackgroundResource(R.color.player_2);

                        //tv_slider.setBackgroundResource(R.drawable.player_2_enable);

                    } else {

                        highlight_winning_positions(new int[0][0], 1, is_game_tied);

                    }
                }
            } else {

                int player = 2;

                values[temp_row][touched_column] = 2;

                flag_for_player_one_turn = true;

                tv_array[temp_row][touched_column].setBackgroundResource(R.drawable.circle_blue);

                tv_pl2_coins.setText(String.valueOf(players_points_counter));

                if (check_for_winner(temp_row, touched_column, player)) {

                    player_2_points = (players_points_counter * 100) + (empty_positiosns * 500);

                    tv_pl2_score.setText("" + player_2_points);

                    updateScoreInSharedPreference("player_2_best_score", String.valueOf(player_2_points),
                            player_2_points);

                    //create dialog for winner

                    //dontTouch = true;

                    return;

                } else {

                    if (!is_game_tied) {

                        tv_pl2_score.setText("" + (players_points_counter * 100));

                        /*tv_player_1_img.setBackgroundResource(R.drawable.player_1_enable);

                        tv_player_2_img.setBackgroundResource(R.drawable.player_2_disable);*/

                        tv_playerTurn.setText(R.string.player_1);

                        tv_playerTurn.setBackgroundResource(R.color.player_1);

                        //tv_slider.setBackgroundResource(R.drawable.player_1_enable);

                    } else {

                        highlight_winning_positions(new int[0][0], 1, is_game_tied);

                    }
                }
            }

            dontTouch = false;

            flip_3d = new Flip3dAnimation(fromAngle, toAngle, centerX, centerY);
            flip_3d.setInterpolator(new AccelerateInterpolator());
            flip_3d.setDuration(800);
            flip_3d.setFillEnabled(true);
            flip_3d.setFillBefore(true);
            flip_3d.setFillAfter(true);
            flip_3d.setAnimationListener(this);

            /*tv_slider.animate().rotationY(location_of_slider[0]);*/

            tv_slider.startAnimation(flip_3d);

        }

        if (animation == flip_3d) {

            if (flag_for_player_one_turn) {

                tv_slider.setBackgroundResource(R.drawable.player_1_enable);

            } else {

                tv_slider.setBackgroundResource(R.drawable.player_2_enable);

            }

            dontTouch = false;

        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.tv_replay:

                win_dialog.cancel();

                rl_game_layout.removeView(rfv_rainfall_pink);
                rl_game_layout.removeView(rfv_rainfall_white);

                for (int i = 0; i < values.length; i++) {

                    for (int j = 0; j < values.length; j++) {

                        values[i][j] = 0;

                        tv_array[i][j].setBackgroundResource(R.drawable.circle);

                    }
                }

                empty_positiosns = 36;

                is_playing_first_time = is_game_tied = dontTouch = false;

                flag_for_player_one_turn = true;

                counter = players_points_counter = player_1_points = player_2_points = 0;

                tv_pl1_score.setText("0");

                tv_pl2_score.setText("0");

                tv_playerTurn.setText(R.string.player_1);

                tv_playerTurn.setBackgroundResource(R.color.player_1);

                tv_pl1_coins.setText("0");

                tv_pl2_coins.setText("0");

                tv_pl1_best_score.setText(sp_best_score.getString("player_1_best_score", "0"));

                tv_pl2_best_score.setText(sp_best_score.getString("player_2_best_score", "0"));

                break;

            case R.id.tv_quit:

                finish();

                break;

            default:

                break;

        }
    }

    private boolean checkFor_Right_Position(int row, int column, int player) {

        int i = row, j = column + 3;

        if (j <= (values.length - 1)/* && (i >= 0 && i <= (row_array.length - 1))*/) {

            for (int k = 0; k < 4; k++) {

                if (values[row][column + k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);
                }
            }
        }

        return (counter == 4);
    }

    private boolean checkFor_Left_Position(int row, int column, int player) {

        int i = row, j = column - 3;

        if (j >= 0) {

            for (int k = 0; k < 4; k++) {

                if (values[row][column - k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        return (counter == 4);

    }

    private boolean checkFor_Top_Position(int row, int column, int player) {

        int i = row - 3, j = column;

        if (i >= 0) {

            for (int k = 0; k < 4; k++) {

                if (values[row - k][column] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        return (counter == 4);
    }

    private boolean checkFor_Bottom_Position(int row, int column, int player) {

        int i = row + 3, j = column;

        if (i <= (values.length - 1)) {

            for (int k = 0; k < 4; k++) {

                if (values[row + k][column] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        return (counter == 4);
    }

    private boolean checkFor_LeftTop_Position(int row, int column, int player) {

        int i = row - 3, j = column - 3;

        if ((i >= 0 && i <= (values.length - 1)) && (j >= 0 && j <= (values.length - 1))) {

            for (int k = 0; k < 4; k++) {

                if (values[row - k][column - k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        if (counter == 4) {

            highlight_winning_positions(new int[][]{{row, column},
                    {(row - 1), (column - 1)},
                    {(row - 2), (column - 2)},
                    {(row - 3), (column - 3)}}, player, is_game_tied);

            return true;

        } else {

            return false;

        }
    }

    private boolean checkFor_RightTop_Position(int row, int column, int player) {

        int i = row - 3, j = column + 3;

        if ((i >= 0 && i <= (values.length - 1)) && (j >= 0 && j <= (values.length - 1))) {

            for (int k = 0; k < 4; k++) {

                if (values[row - k][column + k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        if (counter == 4) {

            highlight_winning_positions(new int[][]{{row, column},
                    {(row - 1), (column + 1)},
                    {(row - 2), (column + 2)},
                    {(row - 3), (column + 3)}}, player, is_game_tied);

            return true;

        } else {

            return false;

        }
    }

    private boolean checkFor_LeftBottom_Position(int row, int column, int player) {

        int i = row + 3, j = column - 3;

        if ((i >= 0 && i <= (values.length - 1)) && (j >= 0 && j <= (values.length - 1))) {

            for (int k = 0; k < 4; k++) {

                if (values[row + k][column - k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        if (counter == 4) {

            highlight_winning_positions(new int[][]{{row, column},
                    {(row + 1), (column - 1)},
                    {(row + 2), (column - 2)},
                    {(row + 3), (column - 3)}}, player, is_game_tied);

            return true;

        } else {

            return false;

        }
    }

    private boolean checkFor_RightBottom_position(int row, int column, int player) {

        int i = row + 3, j = column + 3;

        if ((i >= 0 && i <= (values.length - 1)) && (j >= 0 && j <= (values.length - 1))) {

            for (int k = 0; k < 4; k++) {

                if (values[row + k][column + k] == player) {

                    counter++;

                } else {

                    counter = 0;

                    return (counter == 4);

                }
            }
        }

        if (counter == 4) {

            highlight_winning_positions(new int[][]{{row, column},
                    {(row + 1), (column + 1)},
                    {(row + 2), (column + 2)},
                    {(row + 3), (column + 3)}}, player, is_game_tied);

            return true;

        } else {

            return false;

        }
    }

    private boolean check_sideByside_horizontal(int row, int column, int player) {

        boolean flag = false;

        int i = column + 1, j = column - 1;
        int x = column + 2, y = column - 2;

        if (values[row][column] == player) {

            counter++;

            if ((i >= 0 && i <= (values.length - 1)) && values[row][column + 1] == player) {

                counter++;

            } else {

                counter = 0;

                flag = checkFor_Left_Position(row, column, player);

                if (flag) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {row, (column - 1)},
                            {row, (column - 2)},
                            {row, (column - 3)}}, player, is_game_tied);

                    return true;

                }
            }

            if ((j >= 0 && j <= (values.length - 1)) && (counter == 2) && flag == false &&
                    values[row][column - 1] == player) {

                counter++;

            } else {

                counter = 0;

                flag = false;

                flag = checkFor_Right_Position(row, column, player);

                if (flag) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {row, (column + 1)},
                            {row, (column + 2)},
                            {row, (column + 3)}}, player, is_game_tied);

                    return true;

                }
            }

            if ((x >= 0 && x <= (values.length - 1)) && (counter == 3) && values[row][column + 2] == player &&
                    flag == false) {

                counter++;

                if (counter == 4) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {row, (column + 1)},
                            {row, (column - 1)},
                            {row, (column + 2)}}, player, is_game_tied);

                    return true;

                }

            } else {

                if ((y >= 0 && y <= (values.length - 1)) && (counter == 3) && values[row][column - 2] == player &&
                        flag == false) {

                    counter++;

                    if (counter == 4) {

                        highlight_winning_positions(new int[][]{{row, column},
                                {row, (column + 1)},
                                {row, (column - 1)},
                                {row, (column - 2)}}, player, is_game_tied);

                        return true;

                    }

                } else {

                    counter = 0;

                    return flag;

                }
            }
        }

        return flag;

    }

    private boolean check_TopdownAndBottomup_positions(int row, int column, int player) {

        boolean flag = false;

        int i = row + 1, j = row - 1;
        int x = row + 2, y = row - 2;

        if (values[row][column] == player) {

            counter++;

            if ((i >= 0 && i <= (values.length - 1)) && values[row + 1][column] == player) {

                counter++;

            } else {

                counter = 0;

                flag = false;

                flag = checkFor_Top_Position(row, column, player);

                if (flag) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {(row - 1), column},
                            {(row - 2), column},
                            {(row - 3), column}}, player, is_game_tied);


                    return true;

                }
            }

            if ((j >= 0 && j <= (values.length - 1)) && (counter == 2) && flag == false &&
                    values[row - 1][column] == player) {

                counter++;

            } else {

                counter = 0;

                flag = false;

                flag = checkFor_Bottom_Position(row, column, player);

                if (flag) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {(row + 1), column},
                            {(row + 2), column},
                            {(row + 3), column}}, player, is_game_tied);

                    return true;

                }
            }

            if ((x >= 0 && x <= (values.length - 1)) && (counter == 3) && values[row + 2][column] == player
                    && flag == false) {

                counter++;

                if (counter == 4) {

                    highlight_winning_positions(new int[][]{{row, column},
                            {(row + 1), column},
                            {(row - 1), column},
                            {(row + 2), column}}, player, is_game_tied);

                    return true;

                }

            } else {

                if ((y >= 0 && y <= (values.length - 1)) && (counter == 3) && values[row - 2][column] == player &&
                        flag == false) {

                    counter++;

                    if (counter == 4) {

                        highlight_winning_positions(new int[][]{{row, column},
                                {(row + 1), column},
                                {(row - 1), column},
                                {(row - 2), column}}, player, is_game_tied);

                        return true;

                    }

                } else {

                    counter = 0;

                    return flag;

                }
            }
        }

        return flag;

    }

    private boolean check_for_winner(int row, int column, int player) {

        empty_positiosns = empty_positiosns - 1;

        if (check_sideByside_horizontal(row, column, player)) {

            return true;

        } else if (check_TopdownAndBottomup_positions(row, column, player)) {

            return true;

        } else if (checkFor_LeftTop_Position(row, column, player)) {

            return true;

        } else if (checkFor_RightTop_Position(row, column, player)) {

            return true;

        } else if (checkFor_LeftBottom_Position(row, column, player)) {

            return true;

        } else if (checkFor_RightBottom_position(row, column, player)) {

            return true;

        } else {

            if (empty_positiosns == 0) {

                is_game_tied = true;

                return false;

            } else {

                return false;

            }
        }
    }

    @SuppressLint("NewApi")
    private void highlight_winning_positions(int[][] positions, final int player, final boolean game_tied) {

        /*tv_player_1_img.setBackgroundResource(R.drawable.player_1_disable);

        tv_player_2_img.setBackgroundResource(R.drawable.player_2_disable);*/

        if (!game_tied) {

            rfv_rainfall_pink = new RainFallView(this);
            rfv_rainfall_pink.useImage(R.drawable.rainfall_pink);
            rl_game_layout.addView(rfv_rainfall_pink);

            rfv_rainfall_white = new RainFallView(this);
            rfv_rainfall_white.useImage(R.drawable.rainfall_white);
            rl_game_layout.addView(rfv_rainfall_white);

            win_position_array = positions;

            check_animation = new TranslateAnimation(0.0f, 0.0f, 0.0f, 0.0f);

            check_animation.setAnimationListener(this);

            tv_array[positions[0][0]][positions[0][1]].setBackgroundResource(R.drawable.circle_winner);
            tv_array[positions[0][0]][positions[0][1]].startAnimation(check_animation);

            tv_array[positions[1][0]][positions[1][1]].setBackgroundResource(R.drawable.circle_winner);
            tv_array[positions[1][0]][positions[1][1]].startAnimation(check_animation);

            tv_array[positions[2][0]][positions[2][1]].setBackgroundResource(R.drawable.circle_winner);
            tv_array[positions[2][0]][positions[2][1]].startAnimation(check_animation);

            tv_array[positions[3][0]][positions[3][1]].setBackgroundResource(R.drawable.circle_winner);
            tv_array[positions[3][0]][positions[3][1]].startAnimation(check_animation);

        }

        win_dialog = new Dialog(Game_Activity.this);
        win_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        win_dialog.setContentView(R.layout.winner_dialog_layout);
        win_dialog.setCancelable(false);

        TextView tv_win_msg = (TextView) win_dialog.findViewById(R.id.tv_win_msg);
        if (!game_tied) {

            tv_win_msg.setText("Player " + player + " Won The Game");

        } else {

            tv_win_msg.setText("Game Tied \n\n Better Luck Next Time...");

        }

        TextView tv_replay = (TextView) win_dialog.findViewById(R.id.tv_replay);
        tv_replay.setOnClickListener(this);

        TextView tv_quit = (TextView) win_dialog.findViewById(R.id.tv_quit);
        tv_quit.setOnClickListener(this);

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {

                win_dialog.show();

            }
        }, 1000);
    }

    private void updateScoreInSharedPreference(String key, String best_score, int player_points) {

        if (sp_best_score.contains(key) == true) {

            String pl_best_score = sp_best_score.getString(key, "");

            if (Integer.parseInt(pl_best_score) < player_points) {

                SharedPreferences.Editor sp_edit = sp_best_score.edit();

                sp_edit.putString(key, best_score);

                sp_edit.commit();

            }
        } else {

            SharedPreferences.Editor sp_edit = sp_best_score.edit();

            sp_edit.putString(key, best_score);

            sp_edit.commit();

        }
    }
}

