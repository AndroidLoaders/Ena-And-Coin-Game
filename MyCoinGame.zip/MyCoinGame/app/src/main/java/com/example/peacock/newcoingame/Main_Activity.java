package com.example.peacock.newcoingame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by peacock on 15/3/16.
 */
public class Main_Activity extends AppCompatActivity implements View.OnClickListener {

    public static String pl1_best_score = "0", pl2_best_score = "0";

    private SharedPreferences sp_best_score;

    private TextView tv_pl1_best_score, tv_pl2_best_score;

    private LinearLayout ll_score_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main_activity);

        ll_score_layout = (LinearLayout) findViewById(R.id.ll_score_layout);

        tv_pl1_best_score = (TextView) findViewById(R.id.tv_pl1_best_score);

        tv_pl2_best_score = (TextView) findViewById(R.id.tv_pl2_best_score);

        findViewById(R.id.tv_play).setOnClickListener(this);

        findViewById(R.id.tv_quit).setOnClickListener(this);

        bestScore();

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.tv_play:

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                        Intent i = new Intent(Main_Activity.this, Game_Activity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(i);

                    }
                });

                return;

            case R.id.tv_quit:

                finish();

                return;

            default:

                return;

        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        bestScore();

    }

    private void bestScore() {

        sp_best_score = getSharedPreferences("best_score", Context.MODE_PRIVATE);

        if (sp_best_score.contains("player_1_best_score") == true ||
                sp_best_score.contains("player_2_best_score") == true) {

            pl1_best_score = sp_best_score.getString("player_1_best_score", "0");

            pl2_best_score = sp_best_score.getString("player_2_best_score", "0");

            ll_score_layout.setVisibility(View.VISIBLE);

            tv_pl1_best_score.setText(pl1_best_score);

            tv_pl2_best_score.setText(pl2_best_score);

        } else {

            ll_score_layout.setVisibility(View.GONE);

        }
    }
}
