package com.example.peacock.newcoingame.Flip_3d_Animation;

import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

/**
 * Created by peacock on 16/3/16.
 */
public class FlipAnimationListener implements Animation.AnimationListener {

    private TextView flippingView;
    private String newText;

    public FlipAnimationListener(TextView flippingView, String newText) {

        this.flippingView = flippingView;
        this.newText = newText;
    }

    public void onAnimationEnd(Animation animation) {

        flippingView.setText(newText);

        final float centerX = flippingView.getWidth() / 2.0f;
        final float centerY = flippingView.getHeight() / 2.0f;

        final FlipAnimation1 rotation = new FlipAnimation1(-90, 0, centerX, centerY);

        rotation.setDuration(2000);
        rotation.setFillAfter(true);
        rotation.setInterpolator(new DecelerateInterpolator());

        flippingView.startAnimation(rotation);
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}