package in.gajerait.liveena.utils;

import java.util.ArrayList;

public class StaticDataUtility {

    public static String YOU_TUBE_KEY = "AIzaSyDeTApUjOGOhGUsDG64LZF-KMwtgfyHTjc";

    public static ArrayList<String> ad1 = new ArrayList<>();
    public static ArrayList<String> ad2 = new ArrayList<>();
    public static ArrayList<String> slider = new ArrayList<>();

 }
